#!/bin/bash

clear

echo "Hola $USER"

echo

echo "Vaig a llistar el contingut del directori actual"

echo

ls

echo

echo "Vaig a configurar 2 variables"

COLOR="blau"

VALOR="3"

echo "Aquesta és una cadena de text: $COLOR"

echo "I aquest és un número: $VALOR"

echo

echo "Et retorno al teu prompt"

echo
