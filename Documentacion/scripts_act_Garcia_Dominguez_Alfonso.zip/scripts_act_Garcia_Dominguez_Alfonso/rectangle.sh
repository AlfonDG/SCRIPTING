#!/bin/bash

echo "Hola $USER"

echo

echo "El script rectangle.sh permitirá calcular la superficie de un triangulo rectangulo"

echo

RESULT=$(($1*$2))

echo "El área de base $1 y altura $2 es igual a $RESULT"

