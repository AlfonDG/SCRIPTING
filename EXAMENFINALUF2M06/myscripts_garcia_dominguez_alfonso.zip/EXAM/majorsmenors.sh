#!/bin/bash

while true; do

	echo "==================================================================================================================================="

	echo

	echo "Bienvenido $USER al juego de majormenors.sh, este script se basa en un juego en el que tendrás que adivinar un número al azar"

	echo

	echo "==================================================================================================================================="

	echo

	numeroAzar=$(($RANDOM%100))

	echo $numeroAzar

	intentosRealizados=$(($intentosRealizados + 1))

	echo -n "Introduzca un número a adivinar: "

	read -t 3 numeroAdivinar

	if [[ $numeroAzar -eq $numeroAdivinar ]]; then

		echo "Enhorabuena has adivinado el número al azar que era $numeroAzar"

		echo

		echo "Has logrado esto en un total de $intentosRealizados intentos"

		break

	elif [[ $? -ne 0 ]]; then

		echo "Se ha agotado el tiempo de espera para elegir un número."

		echo

		echo "Saliendo del programa..."

		break

	fi

done
