#!/bin/bash

while true; do

	echo "==============================================================================================="

	echo

	echo "Bienvenido $USER al script registre.sh aquí podrás añadir datos de usuarios en formato .CSV"

	echo

	echo "==============================================================================================="

	echo

	echo -n "Introduzca un nombre: "

	read nombre

	echo

	echo -n "Introduzca el apellido: "

	read apellido

	echo

	echo -n "Introduzca el segundo apellido: "

	read segundoApellido

	echo

	echo -n "Introduzca el sexo de la persona: "

	read sexo

	echo

	echo -n "Introduzca la edad de la persona: "

	read edad

	echo

	echo -n "Introduzca el número de teléfono de la persona: "

	read telefono

	echo

	echo -n "Introduzca el correo electróncio de la persona: "

	read correo

	echo

	echo "Creando el fichero temporal con sus datos, un momento por favor..."

	sleep 1

	touch ficheroTemp.txt

	echo "$nombre,$apellido,$segundoApellido,$sexo,$edad,$telefono,$correo" >> ficheroTemp.txt

	echo

	echo "Creando ahora el fichero en formato .CSV con el listado de datos de los usuarios. Un momento por favor...."

	echo

	echo "También procedemos a borrar el fichero temporal..."

	sleep 2

	cat ficheroTemp.txt >> datosRegistro.csv

	rm ficheroTemp.txt

	echo -n "Deseas seguir añadiendo usuarios [y/n]: "

	read siNoUser


	if [[ $siNoUser == "y" ]]; then


		continue

	elif [[ $siNoUser == "n" ]]; then

		break

	else

		echo "No has seleccionado ninguna de las opciones anteriores"

		echo

		echo "Saliendo del programa debido a error..."

		exit 2

	fi

done
