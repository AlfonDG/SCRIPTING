#!/bin/bash

if [[ $# -eq 0 ]]; then

	echo "Al no haber seleccionado una ruta. Por defecto usaremos su home de usuario $USER que será /home/$(whoami)"

	echo

	ruta="/home/$(whoami)"

else

	ruta=$1

fi

listarContenido=$(ls $ruta)

for i in ${listarContenido}; do

	if [[ -f "$ruta/$i" ]]; then

		echo "$i" | tr "[:upper:]" "[:lower:]"


	elif [[ -d "$ruta/$i" ]]; then

		echo "$i" | tr "[:lower:]" "[:upper:]"
	fi

done
