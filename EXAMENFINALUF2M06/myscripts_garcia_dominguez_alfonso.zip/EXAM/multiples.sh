#!/bin/bash

listaNumeros=$@

if [[ $# -eq 0 ]]; then

	echo "Tienes que pasar al menos un argumento, tú has pasado un total de $# parámetros. Ha de contener 1 $USER"

	echo

	echo "Saliendo del programa"

	exit 1

else

echo "El listado de números anterior es [$@]"

echo

echo -n "Introduzca el número con el que desea evaluar la lista de números anterior: "

read numEvaluar

for i in ${listaNumeros}; do

	if [[ $(($i%$numEvaluar)) -eq 0 ]]; then

		echo "El número $i es múltiplo de $numEvaluar"

	else

		echo "El número $i No es múltiplo de $numEvaluar"

	fi

done


fi
